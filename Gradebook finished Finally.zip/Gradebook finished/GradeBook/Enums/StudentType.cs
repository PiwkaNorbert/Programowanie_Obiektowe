﻿namespace GradeBook.Enums
{
    public enum StudentType
    {
        Standard,
        Honors,
        DualEnrolled
    }
}
