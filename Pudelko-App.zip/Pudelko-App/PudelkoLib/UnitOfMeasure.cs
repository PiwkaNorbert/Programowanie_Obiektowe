﻿namespace PudelkoLib
{
    public sealed partial class Pudelko
    {
        public enum UnitOfMeasure
        {
            meter, centimeter, milimeter
        }
    }
}