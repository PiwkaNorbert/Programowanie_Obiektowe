﻿using Zadanie1.Device;
using Zadanie1.Document;

var xerox = new Copier();
xerox.PowerOn();
IDocument doc1 = new PDFDocument("bbbb.pdf");
xerox.Print(in doc1);

IDocument doc2;
xerox.Scan(out doc2);

xerox.ScanAndPrint();
System.Console.WriteLine(xerox.Counter);
System.Console.WriteLine(xerox.PrintCounter);
System.Console.WriteLine(xerox.ScanCounter);